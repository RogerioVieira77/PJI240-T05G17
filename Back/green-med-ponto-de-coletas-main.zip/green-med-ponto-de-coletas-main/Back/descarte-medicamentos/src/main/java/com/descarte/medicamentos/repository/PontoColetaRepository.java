package com.descarte.medicamentos.repository;

import com.descarte.medicamentos.model.PontoColeta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PontoColetaRepository extends JpaRepository<PontoColeta, Long> {
    List<PontoColeta> findByCep(String cep);
    List<PontoColeta> findByCidade(String cidade);
    List<PontoColeta> findByRegiaoDescr(String regiaoDescr);
    List<PontoColeta> findByRegiaoCod(int regiaoCod);
    List<PontoColeta> findByZona(String zona);
}
