package com.descarte.medicamentos.repository;

import com.descarte.medicamentos.model.UserAdm;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserAdmRepository extends JpaRepository<UserAdm, Integer> {
    Optional<UserAdm> findBycUserAdmNome(String cUserAdmNome);
}