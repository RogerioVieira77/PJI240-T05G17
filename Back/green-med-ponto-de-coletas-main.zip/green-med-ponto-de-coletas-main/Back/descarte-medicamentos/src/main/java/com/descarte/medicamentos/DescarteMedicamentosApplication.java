package com.descarte.medicamentos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DescarteMedicamentosApplication {

	public static void main(String[] args) {
		SpringApplication.run(DescarteMedicamentosApplication.class, args);
	}

}
