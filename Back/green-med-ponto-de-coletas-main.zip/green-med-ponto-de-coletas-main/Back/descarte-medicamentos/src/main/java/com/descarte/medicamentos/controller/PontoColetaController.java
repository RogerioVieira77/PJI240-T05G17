package com.descarte.medicamentos.controller;

import com.descarte.medicamentos.model.PontoColeta;
import com.descarte.medicamentos.service.PontoColetaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/pontos-coleta")
@CrossOrigin(origins = "*", allowCredentials = "false") // Habilita CORS para esse método específico
public class PontoColetaController {

    @Autowired
    private PontoColetaService pontoColetaService;

    // Endpoint para upload de pontos de coleta via arquivo Excel
    @PostMapping("/upload")
    public ResponseEntity<String> uploadPontosColeta(@RequestParam("Coleta_1") MultipartFile file) {
        if (file.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Arquivo está vazio.");
        }

        try {
            pontoColetaService.salvarPontosDeColetaDoExcel(file.getInputStream());
            return ResponseEntity.ok("Pontos de coleta salvos com sucesso!");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Erro ao processar o arquivo: " + e.getMessage());
        }
    }

    // Endpoint para listar todos os pontos de coleta
    @GetMapping
    public ResponseEntity<List<PontoColeta>> getAllPontosColeta() {
        List<PontoColeta> pontos = pontoColetaService.getAllPontosColeta();
        return ResponseEntity.ok(pontos);
    }

    // Endpoint para buscar ponto de coleta por CEP
    @GetMapping("/cep/{cep}")
    public ResponseEntity<List<PontoColeta>> getPontosByCep(@PathVariable String cep) {
        List<PontoColeta> pontos = pontoColetaService.getPontosByCep(cep);
        if (pontos.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(pontos);
        }
        return ResponseEntity.ok(pontos);
    }

    // Endpoint para buscar ponto de coleta por cidade
    @GetMapping("/cidade/{cidade}")
    public ResponseEntity<List<PontoColeta>> getPontosByCidade(@PathVariable String cidade) {
        List<PontoColeta> pontos = pontoColetaService.getPontosByCidade(cidade);
        if (pontos.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(pontos);
        }
        return ResponseEntity.ok(pontos);
    }

    // Novo endpoint para busca por região
    @GetMapping("/regiao/{regiaoDescr}")
    public ResponseEntity<List<PontoColeta>> getPontosByRegiao(@PathVariable String regiaoDescr) {
        List<PontoColeta> pontos = pontoColetaService.getPontosByRegiaoDescr(regiaoDescr);
        if (pontos.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(pontos);
        }
        return ResponseEntity.ok(pontos);
    }

    @GetMapping("/regiao-cod/{regiaoCod}")
    public ResponseEntity<List<PontoColeta>> getPontosByRegiaoCod(@PathVariable int regiaoCod) {
        List<PontoColeta> pontos = pontoColetaService.getPontosByRegiaoCod(regiaoCod);
        if (pontos.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(pontos);
        }
        return ResponseEntity.ok(pontos);
    }

    // Novo endpoint para busca por zona
    @GetMapping("/zona/{zona}")
    public ResponseEntity<List<PontoColeta>> getPontosByZona(@PathVariable String zona) {
        List<PontoColeta> pontos = pontoColetaService.getPontosByZona(zona);
        if (pontos.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(pontos);
        }
        return ResponseEntity.ok(pontos);
    }

    // Endpoint para cadastrar um novo ponto de coleta
    @PostMapping
    public ResponseEntity<PontoColeta> createPontoColeta(@RequestBody PontoColeta pontoColeta) {
        try {
            PontoColeta criado = pontoColetaService.createPontoColeta(pontoColeta);
            return ResponseEntity.status(HttpStatus.CREATED).body(criado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }
}
