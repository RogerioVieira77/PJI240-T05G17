package com.descarte.medicamentos.model;

import jakarta.persistence.*;

@Entity
@Table(name = "users_adm")
public class UserAdm {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "n_useradmid")
    private Integer nUserAdmId;

    @Column(name = "c_useradmnome")
    private String cUserAdmNome;

    @Column(name = "c_useradmemail")
    private String cUserAdmEmail;

    @Column(name = "p_useradmpass")
    private String pUserAdmPass;

    // Getters e Setters
    public String getCUserAdmNome() {
        return cUserAdmNome;
    }

    public void setCUserAdmNome(String cUserAdmNome) {
        this.cUserAdmNome = cUserAdmNome;
    }

    public String getCUserAdmEmail() {
        return cUserAdmEmail;
    }

    public void setCUserAdmEmail(String cUserAdmEmail) {
        this.cUserAdmEmail = cUserAdmEmail;
    }

    public String getPUserAdmPass() {
        return pUserAdmPass;
    }

    public void setPUserAdmPass(String pUserAdmPass) {
        this.pUserAdmPass = pUserAdmPass;
    }
}
