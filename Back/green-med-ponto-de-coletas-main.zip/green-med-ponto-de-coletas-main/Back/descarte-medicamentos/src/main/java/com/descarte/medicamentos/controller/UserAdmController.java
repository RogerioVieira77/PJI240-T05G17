package com.descarte.medicamentos.controller;

import com.descarte.medicamentos.model.UserAdm;
import com.descarte.medicamentos.repository.UserAdmRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*", allowCredentials = "false")
public class UserAdmController {

    @Autowired
    private UserAdmRepository userAdmRepository;

    // Criar novo usuário
    @PostMapping("/create")
    public ResponseEntity<UserAdm> createUser(@RequestBody UserAdm userAdm) {
        return new ResponseEntity<>(userAdmRepository.save(userAdm), HttpStatus.CREATED);
    }

    // Login do usuário
    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody Map<String, String> loginRequest) {
        String username = loginRequest.get("username");
        String password = loginRequest.get("password");

        Optional<UserAdm> user = userAdmRepository.findBycUserAdmNome(username);

        System.out.println(password);

        if (user.isPresent() && user.get().getPUserAdmPass().equals(password)) {
            return ResponseEntity.ok("Login bem-sucedido!");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Credenciais inválidas.");
        }
    }

    // Listar todos os usuários
    @GetMapping
    public ResponseEntity<?> getAllUsers() {
        return ResponseEntity.ok(userAdmRepository.findAll());
    }
}
