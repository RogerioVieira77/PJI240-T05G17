package com.descarte.medicamentos.service;

import com.descarte.medicamentos.model.PontoColeta;
import com.descarte.medicamentos.repository.PontoColetaRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Service
public class PontoColetaService {

    @Autowired
    private PontoColetaRepository pontoColetaRepository;

    // Método para criar um novo PontoColeta
    // Método para criar um novo PontoColeta
    public PontoColeta createPontoColeta(PontoColeta pontoColeta) {
        return pontoColetaRepository.save(pontoColeta);
    }

    // Método para listar todos os pontos de coleta
    public List<PontoColeta> getAllPontosColeta() {
        return pontoColetaRepository.findAll();
    }

    // Métodos de busca
    public List<PontoColeta> getPontosByCep(String cep) {
        return pontoColetaRepository.findByCep(cep);
    }

    public List<PontoColeta> getPontosByCidade(String cidade) {
        return pontoColetaRepository.findByCidade(cidade);
    }

    public List<PontoColeta> getPontosByRegiaoDescr(String regiaoDescr) {
        return pontoColetaRepository.findByRegiaoDescr(regiaoDescr);
    }

    public List<PontoColeta> getPontosByRegiaoCod(int regiaoCod) {
        return pontoColetaRepository.findByRegiaoCod(regiaoCod);
    }

    public List<PontoColeta> getPontosByZona(String zona) {
        return pontoColetaRepository.findByZona(zona);
    }

    // Método para salvar os pontos de coleta a partir de um InputStream (Excel)
    public void salvarPontosDeColetaDoExcel(InputStream inputStream) throws IOException {
        Workbook workbook = new XSSFWorkbook(inputStream);
        Sheet sheet = workbook.getSheetAt(0);

        // Iterar pelas linhas da planilha (ignorando o cabeçalho)
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);

            if (row == null) continue; // Pular linhas vazias

            // Ler os dados da planilha com verificação de tipo de célula
            String nome = getStringCellValue(row.getCell(0));
            String endereco = getStringCellValue(row.getCell(1));
            String cidade = getStringCellValue(row.getCell(2));
            String cep = getStringCellValue(row.getCell(3));
            String estado = getStringCellValue(row.getCell(4));
            double latitude = getNumericCellValue(row.getCell(5));
            double longitude = getNumericCellValue(row.getCell(6));
            String regiaoDescr = getStringCellValue(row.getCell(7));
            int regiaoCod = (int) getNumericCellValue(row.getCell(8));
            String zona = getStringCellValue(row.getCell(9));

            // Criar o objeto PontoColeta e salvar no banco
            PontoColeta pontoColeta = new PontoColeta();
            pontoColeta.setNome(nome);
            pontoColeta.setEndereco(endereco);
            pontoColeta.setCidade(cidade);
            pontoColeta.setCep(cep);
            pontoColeta.setEstado(estado);
            pontoColeta.setLatitude(latitude);
            pontoColeta.setLongitude(longitude);
            pontoColeta.setRegiaoDescr(regiaoDescr);
            pontoColeta.setRegiaoCod(regiaoCod);
            pontoColeta.setZona(zona);

            pontoColetaRepository.save(pontoColeta); // Salvar no banco
        }

        workbook.close();
    }

    // Métodos auxiliares para obter valores das células com verificação de tipo
    private String getStringCellValue(Cell cell) {
        if (cell == null) return "";
        if (cell.getCellType() == CellType.STRING) {
            return cell.getStringCellValue();
        } else if (cell.getCellType() == CellType.NUMERIC) {
            return String.valueOf((int) cell.getNumericCellValue());
        }
        return "";
    }

    private double getNumericCellValue(Cell cell) {
        if (cell == null) return 0.0;
        if (cell.getCellType() == CellType.NUMERIC) {
            return cell.getNumericCellValue();
        }
        return 0.0;
    }
}
