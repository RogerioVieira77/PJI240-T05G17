package com.descarte.medicamentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DescarteMedicamentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
